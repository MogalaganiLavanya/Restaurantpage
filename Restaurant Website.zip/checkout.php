<!DOCTYPE html>
<html>
<head>
    <title>Checkout - Restaurant Website</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    



<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["action"]) && $_POST["action"] === "add_to_cart") {
        // ... (existing logic for adding items to the cart, see previous example)
    } elseif (isset($_POST["action"]) && $_POST["action"] === "get_cart") {
        // ... (existing logic for getting the cart items, see previous example)
    } elseif (isset($_POST["action"]) && $_POST["action"] === "process_order") {
        // Example logic for processing the order
        if (isset($_SESSION["cart"]) && !empty($_SESSION["cart"])) {
            $customerName = $_POST["name"];
            
            $_SESSION["cart"] = array();

            echo json_encode(array("success" => true, "message" => "Order processed successfully!"));
        } else {
            echo json_encode(array("success" => false, "message" => "No items in the cart."));
        }
    }
}

if (isset($_GET["success"]) && $_GET["success"] === "true") {
    echo '<p>Your order was successful! Thank you for your purchase.</p>';
}
?>
<!DOCTYPE html>
<html>
    <style type=text/css>
        body
        {
            background-color:aliceblue;
        }
.menu-item {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px;
}

#cart {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px;
    width: 300px;
   
}
</style>

<head>
    <title>Checkout - Restaurant Website</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    

    <h1 align="center"> Your Order</h1>
    <div id="customer-details">
    <div class="table-container">
            
            <table align="center" cellpadding="15px" border="2px">
                <tr><td>Name</td><td><input type="text" name="urn"></td></tr>
                <tr><td>phone number</td><td><input type="tel" name="phone" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" placeholder="xxx-xxx-xxxx" required></td><tr>
                <tr><td>Email-Id<td><input type="gmail" name="mail"></td></tr>
                <tr><td>Steet</td><td><input type="text" name="street" ></td> </tr>
                <tr><td>City</td><td><input type="text" name="city" ></td> </tr>
                <tr><td>State</td><td><input type="text" name="state"></td> </tr>
                <tr><td>Pincode</td><td><input type="text" name="postalCode" ></td>
            </tr>
            
                <tr><td>Payment process</td><td>
                            <select>
                                <option disabled selected>--select--</option>
                                <option>cash on delivary</option>
                                <option>phonepay</option>
                                <option>gpay</option>
                                <option>paytm</option>
                                <option>credit card</option>
                                <option>debet card</option>
                            </select>
                        </td></tr>




                <tr><td colspan="2" align="center">
                <button><a href="succussfull.php">Place Order</button></td></tr>
    </div>

    


            
        


    
</body>
</html>
