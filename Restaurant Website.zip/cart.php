<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["action"]) && $_POST["action"] === "add_to_cart") {
        $itemName = $_POST["itemName"];
        $itemPrice = floatval($_POST["itemPrice"]);
        
        if (!isset($_SESSION["cart"])) {
            $_SESSION["cart"] = array();
        }

        $_SESSION["cart"][] = array("name" => $itemName, "price" => $itemPrice);
        echo json_encode($_SESSION["cart"]);
    } elseif (isset($_POST["action"]) && $_POST["action"] === "get_cart") {
        if (isset($_SESSION["cart"])) {
            echo json_encode($_SESSION["cart"]);
        } else {
            echo json_encode(array());
        }
    }
   
}    
?>

<!DOCTYPE html>
<html>
<style type=text/css>
        body
        {
            background-color: gainsboro;
        }
</style>
<head>
    <title>Cart - Restaurant Website</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>    
<img src="./shopping-bag-solid-24.png" >
     <big>Your Card</big>
    

    <h3>Delivary-food</h3>
    <div id="cart">
        <ul id="cart-items"></ul>
        <p>Total: <span id="cart-total">$0</span></p>
        <button><a href="checkout.php" >Proceed to Checkout</a></button>
    </div>

    <script src="script.js"></script>
    <script>
        // Function to fetch cart data from the server and update the cart page
        async function getCartItems() {
            try {
                const response = await fetch("cart.php", {
                    method: "POST",
                    body: new URLSearchParams({
                        action: "get_cart"
                    }),
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    }
                });
                const cartItems = await response.json();
                cart = cartItems;
                updateCart();
            } catch (error) {
                console.error("Error fetching cart items:", error);
            }
        }

        // Function to initialize the cart page
        document.addEventListener("DOMContentLoaded", () => {
            getCartItems();
        });
    </script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
    <style type="text/css">


body {
    font-family: Arial, sans-serif;
    margin: 0;` 
    padding: 0;
        }
#mydiv.container {
  display: grid;
  grid-template-columns: auto 2fr; 
  align-items: center;
  gap: 20px; 


#mydiv.container img {
    width: 50px; 
    height: 30px;
}
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Dosa</title>
</head>
<body>  

    <h1 >NL </h1>
    <h2 >Samudram - Indian Kitchen</h2>
<small>South Indian, North Indian, Chinese, Street Food, Desserts, Beverages</small><br>

    <br>
    <h1>Dosa</h1>
    <br>
    <div class="container" id="mydiv">
    
        <img src="./better dosa.jpg" alt="Image" width="300px" height="180px">
       <a><small>$150</small>
        <h3>Butter dosa</h3>
        <p>Golden Crispy Dosai cooked in butter, served with our signature tangy sambar and assortment of chutneys</p>

        <button onclick="addToCart('Butter dosa', 150)">Add to Cart</button>        
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./plain dosa.jpeg" alt="Image" width="300px" height="180px">
       <a><small>$100</small>
        <h3>Dosa</h3>
       
       <p>
        Golden Crispy Dosai cooked in Desi ghee, served with our signature tangy sambar and assortment of chutneys
       </p>
       <button onclick="addToCart('Dosa', 100)">Add to Cart</button>
       </a>
    </div>
    <br>
    
    <div class="container" id="mydiv">
        <img src="./masala dosa.jpg" alt="Image" width="300px" height="180px">
       <a><small>$180</small>
        <h3>Masala dosa</h3>
        <p>Golden Crispy Dosai cooked in Desi ghee along with aloo bhaji, served with our signature tangy sambar and assortment of chutneys.</p>
        <button onclick="addToCart('Masala dosa',180)">Add to Cart</button>
        
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./panner dosa.jpg" alt="Image" width="300px" height="180px">
       <a><small>$250</small>
        <h3>panner dosa</h3>
        <p>
            Hot Garlic chilly paste spread on dosa, served with our signature tangy sambar and assortment of chutneys
        </p>
        
        <button onclick="addToCart('panner dosa',250)">Add to Cart</button>
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./Sagar Ratna.png" alt="Image" width="300px" height="180px">
       <a><small>$250</small>
        <h3>Sagar Ratna dosa</h3>
        <p>
            Hot Sagar Ratna spread on dosa, served with our signature tangy sambar and assortment of chutneys
        </p>
        <button onclick="addToCart('Sagar Ratna dosa',250 )">Add to Cart</button>
        
       </a>
    </div>
    <br>
    
        
       </a>
    </div>
    <br>
   
    <!DOCTYPE html>
<html lang="en">
    <style type="text/css">


body {
    font-family: Arial, sans-serif;
    margin: 0;` 
    padding: 0;
        }
#mydiv.container {
  display: grid;
  grid-template-columns: auto 2fr; 
  align-items: center;
  gap: 20px; 


#mydiv.container img {
    width: 50px; 
    height: 30px;
}
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Biryani</title>
</head>
<body>
    <h1>Biryani</h1>
    
    <br>
    <div class="container" id="mydiv">
    
        <img src="./chicken biryani.png" alt="Image" width="300px" height="180px">
       <a><small>$150</small>
        <h3>special-Chicken biryani</h3>
        <p>special-Chicken biryani is made by layering marinated chicken at the bottom of a pot followed by another layer of par cooked rice, herbs,saffron & ghee.</p>
        <button onclick="addToCart('special-Chicken biryani',150)">Add to Cart</button>
        
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="biryani.jpg" alt="Image" width="300px" height="180px">
       <a><small>$100</small>
        <button onclick="addToCart('special-Chicken biryani',150)">Add to Cart</button>
       
       <p>Hyderabadi chicken biryani is made by layering marinated chicken at the bottom of a pot followed by another layer of par cooked rice, herbs,saffron & ghee. </p>
       <button>Add To Card</button>
       </a>
    </div>
    <br>
    
    <div class="container" id="mydiv">
        <img src="./muttonbiryani.jpg" alt="Image" width="300px" height="180px">
       <a><small>$180</small>
        <h3>Mutton biryani</h3>

        <p>Mutton Hyderabadi biryani is The traditional mutton biryani recipe is made by cooking the raw meat with spices for a couple of minutes and then it is covered with rice.</p>
        <button onclick="addToCart('Mutton biryani',180)">Add to Cart</button>
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./mutton dum.jpg" alt="Image" width="300px" height="180px">
       <a><small>$250</small>
        <h3>dum-Mutton biryani</h3>
        <p>
            Mutton Dum biryani is The traditional mutton dum biryani recipe is made by cooking the raw meat with spices for a couple of minutes and then it is covered with rice.
        </p>
        <button onclick="addToCart('Dum-Mutton biryani',250)">Add to Cart</button>
        
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./dum chicken biryani.jpg" alt="Image" width="300px" height="180px">
       <a><small>$250</small>
        <h3>Dum chicken biryani</h3>
        <p>Dum chicken biryani is made by layering marinated chicken at the bottom of a pot followed by another layer of par cooked rice, herbs,saffron & ghee.
        </p>
        <button onclick="addToCart('dum-Chicken biryani',250)">Add to Cart</button>
        
       </a>
    </div>
    <br>
    
        
        
       
    
        
       </a>
    </div>
    <br>
</body>
</html>

<br>

<!DOCTYPE html>
<html lang="en">
    <style type="text/css">


body {
    font-family: Arial, sans-serif;
    margin: 0;` 
    padding: 0;
        }
#mydiv.container {
  display: grid;
  grid-template-columns: auto 2fr; 
  align-items: center;
  gap: 20px; 


#mydiv.container img {
    width: 50px; 
    height: 30px;
}
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    
    <title>Rolls</title>
</head>
<body>
    <h1>Rolls</h1>
    <div class="container" id="mydiv">
    
        <img src="./rolls.png" alt="Image" width="300px" height="180px">
       <a><small>$150</small>
        <h3>Butter roll </h3>
        
        <button onclick="addToCart('Butter roll ', 150)">Add to Cart</button>
        
        
       </a>
    </div>
    <br>
    
    <div class="container" id="mydiv">
        <img src="./chicken cheese paratha roll.png" alt="Image" width="300px" height="180px">
       <a><small>$210</small>
        <h3>chicken cheese paratha roll</h3>
        <button onclick="addToCart('Chicken cheese paratha roll ',210)">Add to Cart</button>
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./chicken roll.jpg" alt="Image" width="300px" height="180px">
       <a><small>$250</small>
        <h3>chicken roll</h3>
        
        
        <button onclick="addToCart('special-Chicken roll',250)">Add to Cart</button>
      
        
       </a>
    </div>
    <br>
</body>
</html>


<br>
<!DOCTYPE html>
<html lang="en">
    <style type="text/css">


body {
    font-family: Arial, sans-serif;
    margin: 0;` 
    padding: 0;
        }
#mydiv.container {
  display: grid;
  grid-template-columns: auto 2fr; 
  align-items: center;
  gap: 20px; 


#mydiv.container img {
    width: 50px; 
    height: 30px;
}
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Pizza</title>
</head>
<body>
    <h1>Pizza</h1>
        <br>
    <div class="container" id="mydiv">
    
        <img src="./pizza.png" alt="Image" width="300px" height="180px">
       <a><small>$150</small>
        <h3>Pizza</h3>
        
        <button onclick="addToCart('pizza', 150)">Add to Cart</button>
        
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./mutton pizza.jpg" alt="Image" width="300px" height="180px">
       <a><small>$270</small>
        <h3>mutton cheese pizza</h3>
        <button onclick="addToCart('mutton cheese pizza ', 150)">Add to Cart</button>
        
       </a>
    </div>
    <br>
    
    <div class="container" id="mydiv">
        <img src="./chicken pizza.png" alt="Image" width="300px" height="180px">
       <a><small>$210</small>
        <h3>chicken cheese pizza</h3>
        
        <button onclick="addToCart('chicken cheese pizza', 150)">Add to Cart</button>
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./cheese pizza.png" alt="Image" width="300px" height="180px">
       <a><small>$250</small>
        <h3>cheese pizza</h3>  
        <button onclick="addToCart('cheese pizza', 250)">Add to Cart</button>
       </a>
    </div>
    <br>
</body>
</html>
<br>
<!DOCTYPE html>
<html lang="en">
    <style type="text/css">


body {
    font-family: Arial, sans-serif;
    margin: 0;` 
    padding: 0;
        }
#mydiv.container {
  display: grid;
  grid-template-columns: auto 2fr; 
  align-items: center;
  gap: 20px; 


#mydiv.container img {
    width: 50px; 
    height: 30px;
}
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>North Indian</title>
</head>
<body>
    <h1>North Indian </h1>
    
    <div class="container" id="mydiv">
    
        <img src="./pav baji.png" alt="Image" width="300px" height="180px">
       <a><small>$90</small>
        <h3>Pavbhaji</h3>
        <button onclick="addToCart('Pavbhaji', 90)">Add to Cart</button>
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./roti.jpg" alt="Image" width="300px" height="180px">
       <a><small>$150</small>
        <h3>Roti</h3>
        <button onclick="addToCart('Roti ', 150)">Add to Cart</button>
       </a>
    </div>
    <br>
    
    <div class="container" id="mydiv">
        <img src="./png-transparent-south-indian-cuisine.png" alt="Image" width="300px" height="180px">
       <a><small>$210</small>
        <h3>cuisine</h3>
        
        <button onclick="addToCart('cuisine ', 210)">Add to Cart</button>
       </a>
    </div>
    
</body>
</html>
<br>
<!DOCTYPE html>
<html lang="en">
    <style type="text/css">


body {
    font-family: Arial, sans-serif;
    margin: 0;` 
    padding: 0;
        }
#mydiv.container {
  display: grid;
  grid-template-columns: auto 2fr; 
  align-items: center;
  gap: 20px; 


#mydiv.container img {
    width: 50px; 
    height: 30px;
}
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Cake</title>
</head>
<body>
    <h1>Cake </h1>
    
    <br>
    <div class="container" id="mydiv">
    
        <img src="./chocolate cake.png" alt="Image" width="300px" height="180px">
       <a><small>$890</small>
        <h3>chocolate cake</h3>
        <button onclick="addToCart(' chocolate cake', 890)">Add to Cart</button>
       </a>
    </div>
    <br>
    <div class="container" id="mydiv">
        <img src="./pineapple cake.jpg" alt="Image" width="300px" height="180px">
       <a><small>$560</small>
        <h3>pineapple caek</h3>
        <button onclick="addToCart(' pineapple caek', 560)">Add to Cart</button>
        
       </a>
    </div>
    <br>
    
    <div class="container" id="mydiv">
        <img src="./layer dark chocolate cake.jpg" alt="Image" width="300px" height="180px">
       <a><small>$2100</small>
        <h3>layer dark chocolate cake</h3>
        <button onclick="addToCart('layer dark chocolate cake ', 2100)">Add to Cart</button>
        
       </a>
    </div>
    
</body>
</html>


</body>
</html>