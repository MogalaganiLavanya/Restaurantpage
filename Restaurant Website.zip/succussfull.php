<!DOCTYPE html>
<html lang="en">
    <style type="text/css">
    body {
        font-family: Arial, sans-serif;
        margin: 170px;
        padding: 0;
        background-color: #f0f0f0;
      }
      
      .container {
        max-width: 600px;
        margin: 0 auto;
        text-align: center;
        padding: 40px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }
      
      h1 {
        color: #4FC3F7; /* Light Blue */
      }
      
      p {
        margin: 10px 0;
        color: #333;
      }
      
      img {
        width: 80px;
        margin: 20px 0;
      }
      
      a {
        display: inline-block;
        padding: 10px 20px;
        background-color: #4FC3F7;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
      }
      
      a:hover {
        background-color: #29B6F6; 
      }

      @keyframes exampleAnimation {
      0% {
        opacity: 0;
      }
      50% {
        opacity: 0.5;
      }
      100% {
        opacity: 1;
      }
    }

    .animated-element {
      animation: exampleAnimation 2s infinite;
    }
    </style>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Successful</title>
</head>
<body>
  <div class="container">
    <h1>Payment Successful!</h1>
    <p>Thank you. Your payment has been successfully done!</p>
    <button><a href="restutant1.php">back to home</a></button>
    </div>
    
 
</body>
</html>
